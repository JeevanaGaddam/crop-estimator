package com.example.home.cropestimator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Register extends AppCompatActivity {
//EditText name,pd;
//String message,newEntry;
//DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

  /*      Button r=(Button)findViewById(R.id.register);
        Button l=(Button)findViewById(R.id.login);
        name=(EditText)findViewById(R.id.username);
        pd=(EditText)findViewById(R.id.pwd);
/*

        final Spinner s=(Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> a=new ArrayAdapter<String>(Register.this,android.R.layout.simple_expandable_list_item_1,getResources().getStringArray(R.array.type));
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);


*/

        //    mDatabaseHelper=new DatabaseHelper(this);


//final Spinner sp=new Spinner()
     /*
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent log = new Intent(getApplicationContext(), Login.class);
                startActivity(log);
            }

        });

        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(name.getText())) {
                    name.setError("Username is required");
                } else if (TextUtils.isEmpty(pd.getText())) {
                    pd.setError("Password id required");
                } else {
                    String x = name.getText().toString();
                    AddData(x);
                    Intent log = new Intent(getApplicationContext(), Main3.class);
                    startActivity(log);
                }
            }
        });


    }
/*
    public void AddData(String n) {
        boolean insertData = mDatabaseHelper.addData(n);
        if (insertData) {
            toastMessage("Data successfully stored");
        } else {
            toastMessage("Something went wrong");
        }
    }


    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    */

}

}
