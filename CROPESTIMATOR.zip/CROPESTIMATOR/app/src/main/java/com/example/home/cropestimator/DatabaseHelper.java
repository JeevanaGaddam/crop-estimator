package com.example.home.cropestimator;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;

import static android.content.ContentValues.TAG;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final String TABLE_NAME="registration";
private static final String col1="ID";
    private static final String col2="CROP";

    private SQLiteDatabase db;


    public DatabaseHelper(Context context)
    {
        super(context,TABLE_NAME,null,1);

    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }
/*
    public boolean addData(HashMap<String,String> queryValues)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues content=new ContentValues();
        content.put("name"+queryValues.get("name"));
        Log.d(TAG,"addData: Adding"+item+"to"+TABLE_NAME);
        long res=db.insert(TABLE_NAME,null,content);
        if(res==-1)
            return false;
        else
            return true;
    }
    */
}
