package com.example.home.cropestimator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2 extends AppCompatActivity {
    EditText t1,t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1=(EditText)findViewById(R.id.username);
        t2=(EditText)findViewById(R.id.ph);
        Button b1,b2;
        b1=(Button)findViewById(R.id.submit);
        b2=(Button)findViewById(R.id.reset);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(t1.getText())) {
                    t1.setError("Name required");
                }
                if (TextUtils.isEmpty(t2.getText())) {
                    t2.setError("Phone number required");
                } else {

                    Intent a = new Intent(getApplicationContext(), Main3.class);
                    startActivity(a);
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a=new Intent(getApplicationContext(),Main2.class);
                startActivity(a);

            }
        });
    }
}
