package com.example.home.cropestimator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class Main5 extends AppCompatActivity {

    String crop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        final Spinner h =  (Spinner)findViewById(R.id.spinner2);
        Button b = (Button) findViewById(R.id.subb);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ai=new Intent(getApplicationContext(),Main6.class) ;
                crop=h.getSelectedItem().toString();

                ai.putExtra("croptype",crop);

                startActivity(ai);
            }
        });
        Button bac = (Button) findViewById(R.id.back);


        if (getIntent().hasExtra("cropselect")) {
            TextView op = (TextView) findViewById(R.id.op);
            Bundle bd = getIntent().getExtras();

            String txt1 = bd.getString("cropselect");

            op.setText(txt1);
            if (txt1.equalsIgnoreCase("existing crop")) {
                ArrayAdapter<String> a7 = new ArrayAdapter<String>(Main5.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.ex));
                a7.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                h.setAdapter(a7);


            } else {
                if (getIntent().hasExtra("districts")) {
                    Bundle bd1 = getIntent().getExtras();

                    String district = bd.getString("districts");

                    switch (district) {
                        case "Ranga Reddy":
                            ArrayAdapter<String> red1 = new ArrayAdapter<String>(Main5.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.red));
                            red1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            h.setAdapter(red1);

                            break;
                        case "Medak":
                            ArrayAdapter<String> laterite = new ArrayAdapter<String>(Main5.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.laterite));
                            laterite.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            h.setAdapter(laterite);

                            break;
                        case "Yadadri":
                            ArrayAdapter<String> alluvial = new ArrayAdapter<String>(Main5.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.alluvial));
                            alluvial.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            h.setAdapter(alluvial);

                            break;
                        case "Adilabad":
                            ArrayAdapter<String> black = new ArrayAdapter<String>(Main5.this, android.R.layout.simple_expandable_list_item_1, getResources().getStringArray(R.array.black));
                            black.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            h.setAdapter(black);

                            break;

                    }


                }


            }

        }
        bac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ai1=new Intent(getApplicationContext(),Main4.class);
                startActivity(ai1);
            }
        });

    }
}
