package com.example.home.cropestimator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Main4 extends AppCompatActivity {

    String txt,type;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        if (getIntent().hasExtra("district")) {
            TextView op = (TextView) findViewById(R.id.text);
            Bundle bd = getIntent().getExtras();

             txt= bd.getString("district");


            StringBuilder jk = new StringBuilder();

            jk.append("District - ");
            jk.append(txt);

            op.setText(jk);

            switch(txt)
            {
                case "Ranga Reddy":
                    type="Red soil";
                    break;
                case "Medak":
                    type="Laterite soil";
                    break;
                case "Yadadri":
                    type="Alluvial soil";
                    break;
                case "Adilabad":
                    type="Black soil";
                    break;
            }
            TextView st=(TextView)findViewById(R.id.st);
            StringBuilder cv=new StringBuilder();
            cv.append("Soil Type-");
            cv.append(type);
            st.setText(cv);
        }
       Button submit=(Button)findViewById(R.id.submit);
       Button back=(Button)findViewById(R.id.back);


        final Spinner type=(Spinner)findViewById(R.id.type);
        ArrayAdapter<String> ty=new ArrayAdapter<String>(Main4.this,android.R.layout.simple_expandable_list_item_1,getResources().getStringArray(R.array.types));
        ty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        type.setAdapter(ty);




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
           public void onClick(View view) {

String cs=type.getSelectedItem().toString();
                Intent next=new Intent(getApplicationContext(),Main5.class);
                next.putExtra("cropselect",cs);
                next.putExtra("districts",txt);
                startActivity(next);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent b=new Intent(getApplicationContext(),Main3.class);
                startActivity(b);


            }
        });


         }
}
