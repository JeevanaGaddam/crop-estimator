package com.example.home.cropestimator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main6 extends AppCompatActivity {
    String txt1;
    StringBuilder k=new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        if (getIntent().hasExtra("croptype")) {
            TextView op1 = (TextView) findViewById(R.id.t);
            Bundle b = getIntent().getExtras();

            txt1 = b.getString("croptype");
StringBuilder txt2=new StringBuilder();
txt2.append("Crop-");
txt2.append(txt1);
            op1.setText(txt2);


        }
        TextView s=(TextView) findViewById(R.id.info) ;
        switch(txt1)
        {
            case "Millets": k.append("DEFICIENCY IN SOIL \n\n * magnesium \n * Lime \n * Nitrogen \n * Phosphate \n\n\n COMPOSITION OF SOIL\n\n * Iron\n * non soluble matter\n * aluminium ");
            break;
            case "Rice": k.append("DEFICIENCY IN SOIL \n\n * moisture\n * organic matter\n * phosphorous \n \n\nCOMPOSITION  OF SOIL\n\n * lime\n * calcium\n * iron\n * potassium");
            break;
            case "Tea": k.append("DEFICIENCY IN SOIL:\n\n * nitrogen \n * potassium\n\n\n COMPOSITION  OF SOIL\n\n * iron \n * aluminium \n * bauxite");
            break;
            case "SugarCane":k.append("DEFICIENCY IN SOIL:\n\n * phosphorous \n\n\n\nCOMPOSITION OF SOIL\n \n * carbonates\n * organic carbon \n * potash");
            break;

        }
        s.setText(k);
    }

}
